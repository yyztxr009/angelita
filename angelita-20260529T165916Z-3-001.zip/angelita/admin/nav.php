<?php
// Pega o nome do arquivo atual para saber qual link destacar como ativo
$pagina_atual = basename($_SERVER['PHP_SELF']);
?>

<div id="sidebar">
    <h4>Angelita Admin</h4>
    <div class="small text-white-50">Painel de gerenciamento</div>

    <nav class="nav flex-column mt-4">
        <a class="nav-link <?= ($pagina_atual == 'admin.php') ? 'active' : '' ?>" href="admin.php">
            <i class="bi bi-speedometer2"></i> Controle geral
        </a>
        <a class="nav-link <?= ($pagina_atual == 'admin_pedidos.php') ? 'active' : '' ?>" href="admin_pedidos.php">
            <i class="bi bi-receipt"></i> Pedidos
        </a>
        <a class="nav-link <?= ($pagina_atual == 'admin_usuarios.php') ? 'active' : '' ?>" href="admin_usuarios.php">
            <i class="bi bi-people"></i> Usuários
        </a>
        <a class="nav-link <?= ($pagina_atual == 'admin_cardapio.php') ? 'active' : '' ?>" href="admin_cardapio.php">
            <i class="bi bi-book"></i> Produtos
        </a>
        <a class="nav-link" href="../index.php" target="_blank">
            <i class="bi bi-box-arrow-up-right"></i> Ver site
        </a>

        <div class="mt-4 small text-white-50">
            Logado como:
            <strong><?= htmlspecialchars($_SESSION['usuario_nome'] ?? 'Admin') ?></strong>
        </div>
    </nav>
</div>