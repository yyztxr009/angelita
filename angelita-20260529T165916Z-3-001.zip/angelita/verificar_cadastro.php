<?php
session_start();

// Se não houver um e-mail na sessão, manda de volta para o login
if (!isset($_SESSION['email_validando'])) {
    header("Location: login.php");
    exit;
}

// Guarda o e-mail em uma variável antes de qualquer processamento para não dar erro no HTML depois
$email_exibicao = $_SESSION['email_validando'];

$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo_digitado = trim($_POST['codigo'] ?? '');
    $email_usuario = $_SESSION['email_validando'];

    if (!empty($codigo_digitado)) {
        try {
            // Conexão PDO
            $pdo = new PDO("mysql:host=localhost;dbname=tcc1", "root", "");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Busca o usuário que corresponda ao e-mail e ao código digitado
            $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ? AND codigo_verificacao = ?");
            $stmt->execute([$email_usuario, $codigo_digitado]);
            $usuario = $stmt->fetch();

            if ($usuario) {
                // Código correto! Ativa a conta e limpa o código do banco por segurança
                $stmt_update = $pdo->prepare("UPDATE usuarios SET email_verificado = 1, codigo_verificacao = NULL WHERE id = ?");
                $stmt_update->execute([$usuario['id']]);

                // Limpa a sessão temporária
                unset($_SESSION['email_validando']);

                $sucesso = "Conta ativada com sucesso! Você já pode fazer login.";
                
                // Redirecionar após 3 segundos para a página de login
                header("Refresh: 3; url=login.php");
            } else {
                $erro = "Código de verificação incorreto. Tente novamente!";
            }

        } catch (PDOException $e) {
            $erro = "Erro no sistema: " . $e->getMessage();
        }
    } else {
        $erro = "Por favor, digite o código.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Verificar Cadastro - Refeições Angelita</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f7f7f7; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0px 4px 10px rgba(0,0,0,0.1); text-align: center; max-width: 400px; width: 100%; }
        h2 { color: #6a040f; margin-bottom: 10px; }
        p { color: #555; font-size: 14px; }
        input[type="text"] { width: 80%; padding: 10px; font-size: 18px; text-align: center; letter-spacing: 4px; border: 1px solid #ccc; border-radius: 4px; margin: 15px 0; }
        button { background-color: #6a040f; color: white; border: none; padding: 12px 20px; font-size: 16px; border-radius: 4px; cursor: pointer; width: 85%; }
        button:hover { background-color: #9d0208; }
        .error { color: #d00000; font-weight: bold; margin-bottom: 15px; }
        .success { color: #38b000; font-weight: bold; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="box">
    <h2>Ativação de Conta</h2>
    <p>Enviamos um código de 6 dígitos para o e-mail: <br><strong><?php echo htmlspecialchars($email_exibicao); ?></strong></p>
    
    <?php if(!empty($erro)): ?>
        <div class="error"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if(!empty($sucesso)): ?>
        <div class="success"><?php echo $sucesso; ?></div>
    <?php endif; ?>

    <?php if(empty($sucesso)): ?>
        <form method="POST" action="">
            <input type="text" name="codigo" placeholder="000000" maxlength="6" required autocomplete="off">
            <br>
            <button type="submit">Verificar Código</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>