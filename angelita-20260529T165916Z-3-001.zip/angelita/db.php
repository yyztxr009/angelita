<?php
// Configuração para a sessão durar 7 dias
$tempo_sessao = 7 * 24 * 60 * 60;
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params($tempo_sessao);
    ini_set('session.gc_maxlifetime', $tempo_sessao);
}

// ... resto do seu código de conexão do db.php original ...

$host    = "127.0.0.1";
$usuario = "root";
$senha   = "";
$banco   = "tcc1";

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
