<?php
session_start();

// 1. INCLUA OS ARQUIVOS DO PHPMAILER 
// Correção: Caminho ajustado com letras maiúsculas (PHPMailer) e usando __DIR__
require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Conexão PDO
$pdo = new PDO("mysql:host=localhost;dbname=tcc1","root","");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$nome            = trim($_POST['nome'] ?? '');
$email           = trim($_POST['email'] ?? '');
$senha           = $_POST['senha'] ?? '';
$cpf             = trim($_POST['cpf'] ?? '');
$endereco        = trim($_POST['endereco'] ?? '');
$telefone        = trim($_POST['telefone'] ?? '');
$data_nascimento = trim($_POST['data_nascimento'] ?? '');

// Validação básica de campos obrigatórios
if ($nome === '' || $email === '' || $senha === '') {
    header("Location: login.php?erro=campos");
    exit;
}

// Limpa o CPF para deixar apenas números antes de verificar e salvar
$cpf_limpo = preg_replace('/\D/', '', $cpf);
$cpf_db = !empty($cpf_limpo) ? $cpf_limpo : null;

// =========================================================================
// 2. VALIDAÇÃO DE CPF DUPLICADO
// =========================================================================
if ($cpf_db !== null) {
    $stmt_check_cpf = $pdo->prepare("SELECT id FROM usuarios WHERE cpf = ?");
    $stmt_check_cpf->execute([$cpf_db]);
    
    if ($stmt_check_cpf->fetch()) {
        // Se encontrou o CPF, salva o erro na sessão e volta para o formulário
        $_SESSION['erro_cadastro'] = "Este CPF já está cadastrado em nosso sistema!";
        header("Location: login.php"); // Altere para a página correta do formulário se necessário
        exit;
    }
}

// Criptografia da senha
$senha_hash = password_hash($senha, PASSWORD_DEFAULT);

// Tratar os demais campos vazios como NULL
$endereco_db = !empty($endereco) ? $endereco : null;
$telefone_db = !empty($telefone) ? $telefone : null;
$data_nascimento_db = !empty($data_nascimento) ? $data_nascimento : null;

// 3. GERAR O CÓDIGO PIN DE 6 DÍGITOS ALEATÓRIO
$codigo_pin = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

try {
    // Insere o usuário com 'email_verificado' como 0 e salva o código gerado
    $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha_hash, cpf, endereco, telefone, data_nascimento, tipo, codigo_verificacao, email_verificado) VALUES (?, ?, ?, ?, ?, ?, ?, 'cliente', ?, 0)");
    
    $stmt->execute([$nome, $email, $senha_hash, $cpf_db, $endereco_db, $telefone_db, $data_nascimento_db, $codigo_pin]);
    
    // Guarda o e-mail na sessão para ser usado na tela de digitação do código
    $_SESSION['email_validando'] = $email;

    // =========================================================================
    // 4. DISPARO DO E-MAIL COM O CÓDIGO (PHPMailer)
    // =========================================================================
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor Gmail
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = 'refeicoesangelita@gmail.com';   
        $mail->Password   = 'wdbfrhsiadohdeww';  
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
        $mail->Port       = 587; 

        // Remetente e Destinatário
        $mail->setFrom('refeicoesangelita@gmail.com', 'Refeições Angelita'); 
        $mail->addAddress($email, $nome);

        // Conteúdo do E-mail
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = 'Confirmação de Cadastro - Código de Ativação';
        $mail->Body    = "<h3>Olá, {$nome}!</h3>
                          <p>Obrigado por se cadastrar. Use o código abaixo para ativar a sua conta:</p>
                          <h2 style='font-size: 28px; color: #6a040f; letter-spacing: 2px;'><strong>{$codigo_pin}</strong></h2>
                          <p>Se você não realizou este cadastro, por favor ignore este e-mail.</p>";

        $mail->send();
        
        // Redireciona para a nova tela onde o usuário vai digitar o código enviado
        header("Location: verificar_cadastro.php");
        exit;

    } catch (Exception $e) {
        // Força o PHP a mostrar o erro na tela para sabermos o que é
        echo "<h1>Erro ao enviar o e-mail:</h1>";
        echo "Detalhes do erro: " . $mail->ErrorInfo;
        echo "<br><br>Exceção: " . $e->getMessage();
        exit; // Para a execução aqui e não deixa ir para o login
    }
    
} catch (PDOException $e) {
    // Força o PHP a mostrar o erro real do Banco de Dados na tela
    echo "<h1>Erro no Banco de Dados:</h1>";
    echo "Detalhes: " . $e->getMessage();
    exit; // Para tudo e não deixa ir para o login
}